package com.ustwo.app;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.activity.ComponentActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.MediaStoreOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import com.google.common.util.concurrent.ListenableFuture;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

public class MainActivity extends ComponentActivity {
    private final int pink=Color.rgb(255,111,145), deep=Color.rgb(233,79,120);
    private final int pale=Color.rgb(255,247,249), ink=Color.rgb(52,42,45), muted=Color.rgb(138,122,128);
    private FrameLayout root;
    private PreviewView previewView;
    private View tint;
    private TextView decorations, status, record;
    private LinearLayout filterBar;
    private VideoCapture<Recorder> capture;
    private Recording recording;
    private CameraSelector selector=CameraSelector.DEFAULT_FRONT_CAMERA;
    private boolean recordingNow=false, hearts=true, cameraScreen=false;
    private int filterIndex=1;
    private Uri lastUri;
    private final String[] filterNames={"Natural","Pink Glow","Dreamy","Sunset","Film","B&W"};
    private final int[] filterColors={Color.TRANSPARENT,Color.argb(54,255,105,155),Color.argb(50,190,170,255),Color.argb(52,255,155,90),Color.argb(40,35,25,30),Color.argb(75,20,20,20)};
    private final ActivityResultLauncher<String[]> permissionLauncher=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result->{
        if(Boolean.TRUE.equals(result.get(Manifest.permission.CAMERA))) showCamera();
        else Toast.makeText(this,"Camera permission is needed.",Toast.LENGTH_LONG).show();
    });

    @Override public void onCreate(Bundle b){super.onCreate(b);home();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(null,android.graphics.Typeface.BOLD);return t;
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private Button button(String s,Runnable r){
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(pink));b.setOnClickListener(v->r.run());return b;
    }
    private void setRoot(View v){root=new FrameLayout(this);root.setBackgroundColor(pale);root.setFitsSystemWindows(true);root.addView(v,new FrameLayout.LayoutParams(-1,-1));setContentView(root);}
    private void home(){
        cameraScreen=false; LinearLayout p=col();p.setPadding(dp(20),dp(20),dp(20),dp(18));
        TextView logo=text("UsTwo ♡",32,ink,true);logo.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD_ITALIC));p.addView(logo);
        p.addView(text("Our vlogs. Our story.",13,muted,false));
        TextView hero=text("A LITTLE REMINDER\nEven miles apart, we share the little things. 💗",21,ink,true);
        hero.setPadding(dp(16),dp(20),dp(16),dp(20));hero.setBackgroundColor(Color.rgb(255,226,231));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(22);p.addView(hero,hp);
        TextView title=text("Little moments",20,ink,true);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=dp(20);p.addView(title,tp);
        addCard(p,"My day with you 💗","You · Sample vlog","🌅",Color.rgb(247,198,189));
        addCard(p,"Little sunset moments","Partner · Sample vlog","🌇",Color.rgb(246,213,182));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(54));bp.topMargin=dp(12);p.addView(button("◎  Record a vlog",this::requestCamera),bp);
        p.addView(button("▶  Preview last recording",this::playLast));
        TextView note=text("🔒 Cloud sharing needs Firebase setup.",12,muted,false);note.setPadding(0,dp(12),0,0);p.addView(note);
        setRoot(p);
    }
    private void addCard(LinearLayout p,String title,String meta,String emoji,int color){
        LinearLayout c=col();c.setPadding(dp(10),dp(10),dp(10),dp(10));c.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(12);p.addView(c,cp);
        TextView cover=text(emoji+"     ▶",34,deep,true);cover.setGravity(Gravity.CENTER);cover.setBackgroundColor(color);c.addView(cover,new LinearLayout.LayoutParams(-1,dp(100)));
        TextView t=text(title,14,ink,true);LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(-1,-2);x.topMargin=dp(8);c.addView(t,x);c.addView(text(meta,11,muted,false));
    }
    private void requestCamera(){
        boolean cam=ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED;
        boolean mic=ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED;
        if(cam&&mic)showCamera();else permissionLauncher.launch(new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO});
    }
    private void showCamera(){
        cameraScreen=true;root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);
        previewView=new PreviewView(this);previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);root.addView(previewView,new FrameLayout.LayoutParams(-1,-1));
        tint=new View(this);tint.setBackgroundColor(filterColors[filterIndex]);root.addView(tint,new FrameLayout.LayoutParams(-1,-1));
        decorations=text(hearts?"♥                         ♥\n\n             ✦":"",32,Color.rgb(255,170,195),true);decorations.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        FrameLayout.LayoutParams ep=new FrameLayout.LayoutParams(-1,dp(170),Gravity.TOP);ep.topMargin=dp(100);root.addView(decorations,ep);
        LinearLayout panel=col();panel.setPadding(dp(12),dp(10),dp(12),dp(18));panel.setBackgroundColor(Color.argb(185,18,13,16));
        root.addView(panel,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);panel.addView(top);
        TextView close=text("×",30,Color.WHITE,false);close.setGravity(Gravity.CENTER);top.addView(close,new LinearLayout.LayoutParams(dp(48),dp(44)));close.setOnClickListener(v->{stopIfNeeded();home();});
        status=text("1080p · "+filterNames[filterIndex],13,Color.WHITE,true);top.addView(status,new LinearLayout.LayoutParams(0,-2,1));
        TextView flip=text("↻",28,Color.WHITE,true);flip.setGravity(Gravity.CENTER);top.addView(flip,new LinearLayout.LayoutParams(dp(48),dp(44)));flip.setOnClickListener(v->flipCamera());
        filterBar=new LinearLayout(this);filterBar.setGravity(Gravity.CENTER);panel.addView(filterBar);
        for(int i=0;i<filterNames.length;i++){final int n=i;TextView f=text(filterNames[i],10,i==filterIndex?pink:Color.WHITE,i==filterIndex);f.setGravity(Gravity.CENTER);f.setPadding(dp(3),dp(12),dp(3),dp(12));filterBar.addView(f,new LinearLayout.LayoutParams(0,-2,1));f.setOnClickListener(v->applyFilter(n));}
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);panel.addView(actions);
        TextView effect=text("♥\nEffects",12,Color.WHITE,true);effect.setGravity(Gravity.CENTER);actions.addView(effect,new LinearLayout.LayoutParams(0,dp(66),1));
        effect.setOnClickListener(v->{hearts=!hearts;decorations.setText(hearts?"♥                         ♥\n\n             ✦":"");effect.setText(hearts?"♥\nEffects":"♡\nEffects");});
        record=text("●",50,pink,true);record.setGravity(Gravity.CENTER);actions.addView(record,new LinearLayout.LayoutParams(0,dp(68),1));record.setOnClickListener(v->{if(recordingNow)stopRecording();else startRecording();});
        TextView flip2=text("↻\nFlip",12,Color.WHITE,true);flip2.setGravity(Gravity.CENTER);actions.addView(flip2,new LinearLayout.LayoutParams(0,dp(66),1));flip2.setOnClickListener(v->flipCamera());
        panel.addView(button("Preview last recording",this::playLast));
        setContentView(root);startCamera();
    }
    private void flipCamera(){selector=selector==CameraSelector.DEFAULT_FRONT_CAMERA?CameraSelector.DEFAULT_BACK_CAMERA:CameraSelector.DEFAULT_FRONT_CAMERA;startCamera();}
    private void applyFilter(int n){
        filterIndex=n;if(tint!=null)tint.setBackgroundColor(filterColors[n]);if(status!=null)status.setText("1080p · "+filterNames[n]);
        if(filterBar!=null)for(int i=0;i<filterBar.getChildCount();i++){TextView t=(TextView)filterBar.getChildAt(i);t.setTextColor(i==n?pink:Color.WHITE);t.setTypeface(null,i==n?1:0);}
    }
    private void startCamera(){
        if(!cameraScreen||previewView==null)return;
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{try{
            ProcessCameraProvider provider=future.get();Preview preview=new Preview.Builder().build();preview.setSurfaceProvider(previewView.getSurfaceProvider());
            Recorder recorder=new Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD)).build();capture=VideoCapture.withOutput(recorder);
            provider.unbindAll();provider.bindToLifecycle(this,selector,preview,capture);
        }catch(ExecutionException|InterruptedException e){Toast.makeText(this,"Camera failed to start.",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Camera error: "+e.getMessage(),Toast.LENGTH_LONG).show();}},ContextCompat.getMainExecutor(this));
    }
    private void startRecording(){
        if(capture==null||recordingNow)return;
        String name="UsTwo_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".mp4";
        ContentValues cv=new ContentValues();cv.put(MediaStore.MediaColumns.DISPLAY_NAME,name);cv.put(MediaStore.MediaColumns.MIME_TYPE,"video/mp4");cv.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/UsTwo");
        MediaStoreOutputOptions output=new MediaStoreOutputOptions.Builder(getContentResolver(),MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(cv).build();
        PendingRecording pending=capture.getOutput().prepareRecording(this,output);
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)pending=pending.withAudioEnabled();
        recording=pending.start(ContextCompat.getMainExecutor(this),event->{
            if(event instanceof VideoRecordEvent.Start){recordingNow=true;record.setText("■");record.setTextColor(Color.RED);}
            else if(event instanceof VideoRecordEvent.Finalize){recordingNow=false;record.setText("●");record.setTextColor(pink);VideoRecordEvent.Finalize fin=(VideoRecordEvent.Finalize)event;
                if(!fin.hasError()){lastUri=fin.getOutputResults().getOutputUri();Toast.makeText(this,"Saved in Movies/UsTwo",Toast.LENGTH_LONG).show();}
                else Toast.makeText(this,"Recording failed. Try again.",Toast.LENGTH_LONG).show();recording=null;}
        });
    }
    private void stopRecording(){if(recording!=null)recording.stop();}
    private void stopIfNeeded(){if(recording!=null)recording.stop();}
    private void playLast(){if(lastUri==null){Toast.makeText(this,"Record a video first.",Toast.LENGTH_LONG).show();return;}play(lastUri);}
    private void play(Uri uri){
        cameraScreen=false;LinearLayout p=col();p.setPadding(dp(18),dp(18),dp(18),dp(18));p.addView(text("Review your vlog 💗",24,ink,true));
        VideoView video=new VideoView(this);LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,dp(420));vp.topMargin=dp(16);p.addView(video,vp);video.setVideoURI(uri);video.setOnPreparedListener(mp->{mp.setLooping(false);video.start();});
        TextView privacy=text("Saved locally. Private cloud sharing needs Firebase setup.",12,muted,false);privacy.setPadding(0,dp(12),0,dp(12));p.addView(privacy);
        p.addView(button("Upload to our private space",()->Toast.makeText(this,"Cloud upload is not active until partner membership and Firebase security rules are configured.",Toast.LENGTH_LONG).show()));
        p.addView(button("Back home",this::home));setRoot(p);
    }
    @Override protected void onDestroy(){stopIfNeeded();super.onDestroy();}
}
