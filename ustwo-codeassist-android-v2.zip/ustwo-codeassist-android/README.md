# UsTwo — CodeAssist Android project

Native Java + Gradle starter intended for Android IDEs that can import standard Gradle Android projects, including CodeAssist where supported.

## Included
- CameraX preview, front/rear switching, recording with microphone audio
- Video saved locally to Movies/UsTwo
- Playback of the latest recording
- Cute pink UI, filter tint overlays (Natural, Pink Glow, Dreamy, Sunset, Film, B&W)
- Heart/sparkle overlay toggle
- Firebase Auth, Firestore and Storage dependencies as the foundation for private sharing

## Open in CodeAssist
1. Extract this ZIP on your Android device.
2. In CodeAssist, choose Open Project and select the extracted folder containing `settings.gradle`.
3. Allow Gradle sync and dependency downloads.
4. Use Java 17 if asked for the Gradle JDK.
5. Run on a physical Android phone and grant camera/microphone permissions.

If your version of CodeAssist cannot sync Android Gradle Plugin 8.7.3 / SDK 35, update its build tools or use Android Studio. Phone IDEs can vary in their Gradle support.

## Private sharing setup
The upload action is deliberately a placeholder: local recording works, but it does not pretend clips are shared. To enable private cross-device uploads:
1. Create a Firebase project and register Android app ID `com.ustwo.app`.
2. Add `google-services.json` to `app/` and configure the Google Services Gradle plugin using Firebase's current instructions.
3. Enable Firebase Authentication, Cloud Firestore and Cloud Storage.
4. Implement sign-in for both partners and a couple invitation/membership flow.
5. Upload to `couples/{coupleId}/vlogs/{vlogId}.mp4`, store caption/author/time metadata in Firestore, and enforce strict rules verifying the authenticated user is a member of that couple.
6. Never deploy permissive test rules. Add file-size/type limits and deletion/export controls.

## Effects limitations
Color tints and heart/sparkle graphics are live preview overlays; they are not baked into the saved recording and are not face-tracked AR masks. Advanced face-tracking effects need a native graphics/face-landmark SDK and video processing.

## Troubleshooting
- Black preview: check camera permission and test on a physical device.
- No audio: grant microphone permission.
- Sync failure: check Java 17, SDK 35 and Gradle/AGP compatibility.
- Cloud upload: not enabled until Firebase Auth, couple membership and strict security rules are implemented.
